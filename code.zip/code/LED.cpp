#include "LED.h"

#include <Arduino.h>
#include "state.h"

// LED CODES:
// 200ms blinking - fatal error.
// 500ms blinking - need to calibrate.
// 100ms blinking - calibrating.
// contiuous      - normal operation / calibration complete.
void update_LED() {
  static unsigned long last = 0;

  switch(globalState) {
    case S_WAITING_CALIBRATION:
      if (micros() - last > 500) {
        digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
      }
      break;
  }
}