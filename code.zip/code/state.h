#ifndef _STATE_H
#define _STATE_H

enum State {
  S_WAITING_CALIBRATION,
  S_CALIBRATING,
  S_CALIBRATED,
};

enum State globalState;
#endif